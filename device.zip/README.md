# Device Login - PHP Version (cPanel Hosting)

Microsoft device code flow for OAuth. Host on cPanel or any PHP hosting.

## Requirements

- PHP 7.4+ with **curl** extension
- HTTPS (recommended for production)
- Azure app with "Allow public client flows" = Yes

## Setup

1. **Upload** the entire `device_login_php` folder to your hosting (e.g. `public_html/device-login/`)

2. **Edit** `config.php` – set your Azure **Client ID**:
   ```php
   define('CLIENT_ID', 'your-azure-client-id-here');
   ```

3. **Permissions** – ensure `data/` folder is writable (chmod 755 or 775):
   - Tokens and accounts are stored in `data/`
   - The app creates `data/` automatically if it doesn't exist

4. **Subfolder install** – if the app is in a subfolder (e.g. `yoursite.com/device-login/`):
   - Edit `.htaccess` and set `RewriteBase /device-login/` if you use the revoke rewrite rule
   - The admin panel detects the base path automatically

## URLs

| Page        | URL                    |
|-------------|------------------------|
| Login       | `index.php`            |
| Verify      | `verify.php?email=...`|
| Admin panel | `admin.php`           |

## File Structure

```
device_login_php/
├── config.php           # Edit CLIENT_ID here
├── index.php            # Email entry
├── verify.php           # Device code flow
├── admin.php            # Admin panel
├── app_config.json      # App name, copyright
├── app_permissions.json # Scopes
├── .htaccess
├── data/                # Writable - tokens, accounts (auto-created)
├── api/
│   ├── start.php
│   ├── status.php
│   └── admin/
│       ├── accounts.php
│       ├── mails.php
│       ├── revoke.php
│       └── permissions.php
├── includes/
│   └── helpers.php
└── templates/
    ├── email_enter.html
    └── device_login.html
```

## Azure App Checklist

- Supported accounts: **Any Entra ID Tenant + Personal Microsoft accounts**
- Authentication → Allow public client flows: **Yes**
- API permissions (Delegated): **Mail.Read**, **Mail.Send**, **User.Read**
- Redirect URI: Optional for device flow (or add `https://login.microsoftonline.com/common/oauth2/nativeclient`)
