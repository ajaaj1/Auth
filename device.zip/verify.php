<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/helpers.php';

$html = file_get_contents(__DIR__ . '/templates/device_login.html');
echo injectConfig($html);
