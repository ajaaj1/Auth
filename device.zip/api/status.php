<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!file_exists(DEVICE_FLOW_FILE)) {
    echo json_encode(['status' => 'waiting']);
    exit;
}

$flow = @json_decode(file_get_contents(DEVICE_FLOW_FILE), true);
if (!$flow || empty($flow['device_code'])) {
    echo json_encode(['status' => 'waiting']);
    exit;
}

$resp = httpPost('https://login.microsoftonline.com/common/oauth2/v2.0/token', [
    'grant_type' => 'urn:ietf:params:oauth:grant-type:device_code',
    'device_code' => $flow['device_code'],
    'client_id' => CLIENT_ID,
]);

$data = @json_decode($resp['body'], true);

if ($resp['code'] === 200 && isset($data['access_token'])) {
    @unlink(DEVICE_FLOW_FILE);
    $email = $data['id_token_claims']['preferred_username'] ?? $data['id_token_claims']['upn'] ?? 'unknown';
    saveToken($email, $data);
    echo json_encode(['status' => 'connected', 'email' => $email]);
    exit;
}

if (isset($data['error'])) {
    if ($data['error'] === 'authorization_pending') {
        echo json_encode(['status' => 'pending']);
    } elseif (in_array($data['error'], ['authorization_declined', 'expired_token', 'bad_verification_code'])) {
        @unlink(DEVICE_FLOW_FILE);
        echo json_encode(['status' => 'error', 'error' => $data['error_description'] ?? $data['error']]);
    } else {
        echo json_encode(['status' => 'pending']);
    }
} else {
    echo json_encode(['status' => 'pending']);
}

function saveToken($email, $tokenData) {
    ensureDataDir();
    $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $email);
    $path = DATA_DIR . "/token_{$safe}.json";
    $tokenData['expires_on'] = time() + ($tokenData['expires_in'] ?? 3600);
    file_put_contents($path, json_encode($tokenData, JSON_PRETTY_PRINT));

    $accounts = [];
    if (file_exists(MAILER_ACCOUNTS_FILE)) {
        $accounts = @json_decode(file_get_contents(MAILER_ACCOUNTS_FILE), true) ?: [];
    }
    $name = explode('@', $email)[0] ?? $email;
    $accounts[$email] = [
        'name' => $name,
        'logged_in' => true,
        'connected_at' => gmdate('Y-m-d H:i:s') . ' UTC',
    ];
    file_put_contents(MAILER_ACCOUNTS_FILE, json_encode($accounts, JSON_PRETTY_PRINT));
}
