<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    echo json_encode(['scopes' => getScopes()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $input = @json_decode(file_get_contents('php://input'), true) ?: [];
    $scopes = array_filter($input['scopes'] ?? [], function ($s) {
        return !in_array($s, RESERVED_SCOPES);
    });
    $scopes = array_values($scopes);
    file_put_contents(APP_PERMISSIONS_FILE, json_encode(['scopes' => $scopes], JSON_PRETTY_PRINT));
    echo json_encode(['ok' => true, 'scopes' => $scopes]);
    exit;
}
