<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$email = $_GET['email'] ?? '';
if (empty($email)) {
    $input = @json_decode(file_get_contents('php://input'), true);
    $email = $input['email'] ?? '';
}
if (empty($email)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email required']);
    exit;
}

$accounts = [];
if (file_exists(MAILER_ACCOUNTS_FILE)) {
    $accounts = @json_decode(file_get_contents(MAILER_ACCOUNTS_FILE), true) ?: [];
}
if (isset($accounts[$email])) {
    unset($accounts[$email]);
    file_put_contents(MAILER_ACCOUNTS_FILE, json_encode($accounts, JSON_PRETTY_PRINT));
}

$safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $email);
$tokenPath = DATA_DIR . "/token_{$safe}.json";
if (file_exists($tokenPath)) {
    @unlink($tokenPath);
}

echo json_encode(['ok' => true]);
