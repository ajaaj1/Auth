<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/helpers.php';

$accounts = [];
if (file_exists(MAILER_ACCOUNTS_FILE)) {
    $accounts = @json_decode(file_get_contents(MAILER_ACCOUNTS_FILE), true) ?: [];
}
echo json_encode(['accounts' => $accounts]);
