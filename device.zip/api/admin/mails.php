<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/helpers.php';

function getValidToken($email) {
    $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $email);
    $path = DATA_DIR . "/token_{$safe}.json";
    if (!file_exists($path)) return null;
    $data = @json_decode(file_get_contents($path), true);
    if (!$data) return null;
    $expiresOn = $data['expires_on'] ?? (time() + ($data['expires_in'] ?? 3600));
    if (time() >= $expiresOn - 300) {
        $resp = httpPost('https://login.microsoftonline.com/common/oauth2/v2.0/token', [
            'grant_type' => 'refresh_token',
            'refresh_token' => $data['refresh_token'] ?? '',
            'client_id' => CLIENT_ID,
        ]);
        if ($resp['code'] !== 200) return null;
        $tok = @json_decode($resp['body'], true);
        if (!$tok || empty($tok['access_token'])) return null;
        $data['access_token'] = $tok['access_token'];
        $data['expires_in'] = $tok['expires_in'] ?? 3600;
        $data['expires_on'] = time() + $data['expires_in'];
        if (!empty($tok['refresh_token'])) $data['refresh_token'] = $tok['refresh_token'];
        file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT));
    }
    return $data['access_token'] ?? null;
}

function fetchMailsWithAttachments($accessToken) {
    $url = 'https://graph.microsoft.com/v1.0/me/messages?' . http_build_query([
        '$filter' => 'hasAttachments eq true',
        '$top' => 999,
        '$expand' => 'attachments($select=name,contentType,size)',
        '$select' => 'subject,from,receivedDateTime,hasAttachments,bodyPreview',
    ]);
    $allMsgs = [];
    while ($url) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json',
            ],
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code !== 200) break;
        $data = @json_decode($resp, true);
        foreach ($data['value'] ?? [] as $m) {
            $fromAddr = '';
            if (is_array($m['from'] ?? null)) {
                $fe = $m['from']['emailAddress'] ?? [];
                $fromAddr = $fe['address'] ?? '';
            }
            $atts = [];
            foreach ($m['attachments'] ?? [] as $a) {
                $name = $a['name'] ?? explode('/', $a['contentType'] ?? '')[1] ?? 'file';
                $atts[] = ['name' => $name, 'type' => $a['contentType'] ?? '', 'size' => $a['size'] ?? 0];
            }
            if (!empty($m['hasAttachments']) && empty($atts)) {
                $atts[] = ['name' => '(attachments)', 'type' => '', 'size' => 0];
            }
            $allMsgs[] = [
                'subject' => $m['subject'] ?? '(No subject)',
                'from' => $fromAddr,
                'date' => $m['receivedDateTime'] ?? '',
                'bodyPreview' => substr($m['bodyPreview'] ?? '', 0, 200),
                'attachments' => $atts,
            ];
        }
        $url = $data['@odata.nextLink'] ?? null;
    }
    usort($allMsgs, function ($a, $b) {
        return strcasecmp($a['subject'] ?? '', $b['subject'] ?? '');
    });
    return $allMsgs;
}

$accounts = [];
if (file_exists(MAILER_ACCOUNTS_FILE)) {
    $accounts = @json_decode(file_get_contents(MAILER_ACCOUNTS_FILE), true) ?: [];
}

$allMails = [];
foreach (array_keys($accounts) as $email) {
    $token = getValidToken($email);
    if (!$token) continue;
    try {
        $msgs = fetchMailsWithAttachments($token);
        foreach ($msgs as $m) {
            $m['account'] = $email;
            $allMails[] = $m;
        }
    } catch (Exception $e) {
        $allMails[] = ['account' => $email, 'error' => $e->getMessage(), 'subject' => '(fetch failed)'];
    }
}

$valid = array_filter($allMails, function ($m) { return empty($m['error']); });
$errors = array_filter($allMails, function ($m) { return !empty($m['error']); });
usort($valid, function ($a, $b) { return strcasecmp($a['subject'] ?? '', $b['subject'] ?? ''); });

echo json_encode(['mails' => array_merge($valid, $errors), 'accounts' => $accounts]);
