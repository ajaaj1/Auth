<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/helpers.php';

ensureDataDir();

$scopes = getScopes();
$scopeStr = implode(' ', array_merge($scopes, ['offline_access', 'openid', 'profile']));

$resp = httpPost('https://login.microsoftonline.com/common/oauth2/v2.0/devicecode', [
    'client_id' => CLIENT_ID,
    'scope' => $scopeStr,
]);

$data = @json_decode($resp['body'], true);
if ($resp['code'] !== 200 || !isset($data['user_code'])) {
    http_response_code(400);
    echo json_encode(['error' => $data['error_description'] ?? 'Failed to start device flow']);
    exit;
}

file_put_contents(DEVICE_FLOW_FILE, json_encode([
    'device_code' => $data['device_code'],
    'user_code' => $data['user_code'],
    'verification_uri' => $data['verification_uri'] ?? 'https://microsoft.com/devicelogin',
    'message' => $data['message'] ?? '',
    'expires_in' => $data['expires_in'] ?? 900,
    'interval' => $data['interval'] ?? 5,
]));

echo json_encode([
    'user_code' => $data['user_code'],
    'verification_uri' => $data['verification_uri'] ?? 'https://microsoft.com/devicelogin',
    'message' => $data['message'] ?? '',
]);
