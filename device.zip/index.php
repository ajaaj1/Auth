<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/helpers.php';

$html = file_get_contents(__DIR__ . '/templates/email_enter.html');
echo injectConfig($html);
