<?php
/**
 * Device Login - PHP config for cPanel hosting
 * Edit CLIENT_ID to match your Azure app
 */
define('CLIENT_ID', '0506209c-0846-4014-ae0b-ee9c39411517');
define('AUTHORITY', 'https://login.microsoftonline.com/common');
define('RESERVED_SCOPES', ['offline_access', 'profile', 'openid']);

$baseDir = __DIR__;
define('DATA_DIR', $baseDir . '/data');
define('APP_CONFIG_FILE', $baseDir . '/app_config.json');
define('APP_PERMISSIONS_FILE', $baseDir . '/app_permissions.json');
define('MAILER_ACCOUNTS_FILE', DATA_DIR . '/mailer_accounts.json');
define('DEVICE_FLOW_FILE', DATA_DIR . '/device_flow.json');
